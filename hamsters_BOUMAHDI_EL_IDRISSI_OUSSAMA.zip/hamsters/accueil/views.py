from django.http import HttpResponse


def index(request):
    return HttpResponse("<h1>Bienvenue a l'animalerie!</h1>"
                        "<h2>Tableau de bord</h2>"
                        "<p>TIC : fatigué, roue</p>"
                        "<p>TAC : repus, mangeoire</p>"
                        "<p>TOTORO : endormi, nid</p>"
                        "<p>PATRICK : affame, litiere</p>"
                        "<p>POCAHONTAS : affame, litiere</p>"
                        "<h2>Actions</h2>"
                        "<form action=''>"
                           "<input type='radio' name='AnimalName' value='tic'> TIC<br>"
                           "<input type='radio' name='AnimalName' value='tac'> TAC<br>"
                           "<input type='radio' name='AnimalName' value='totoro'> TOTORO<br>"
                           "<input type='radio' name='AnimalName' value='patrick'> PATRICK<br>"
                           "<input type='radio' name='AnimalName' value='pocahontas'> POCAHONTAS<br>"
                        "</form>"

                        "<form action=''>"
                          "<input type='radio' name='action' value='nourrir'> Nourrir<br>"
                          "<input type='radio' name='action' value='divertir'> Divertir<br>"
                          "<input type='radio' name='action' value='coucher'> Coucher<br>"
                          "<input type='radio' name='action' value='reveiller'> Reveiller<br>"
                        "</form>"
                        "<input type='button' value='submit' />")
